GazVariables = {
	MinionsNow = 2,
	MaxSummons = 7,
}
